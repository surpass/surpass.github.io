<!--
This form is for bug reports and feature requests ONLY!  
If you're looking for help check out [our support guidelines](/SUPPORT.md).
-->
**Bug report**

**What happened**:

**What you expected to happen**:

**How to reproduce it (as minimally and precisely as possible)**:

**Anything else we need to know?**:

**Environment**:
- Syna Theme version:  
- Hugo version:  
- Others:
