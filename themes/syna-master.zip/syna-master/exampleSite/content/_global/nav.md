+++
fragment = "nav"
#disabled = true
date = "2018-05-17"
weight = 0
background = "dark"
search = true
sticky = true

[breadcrumb]
  display = true # Default value is false
  #level = 0 # Default is 1
  background = "light"

# Branding options
[asset]
  image = "logo.svg"
  text = "Syna"

[repo_button]
  url = "https://github.com/okkur/syna"
  text = "Star" # default: "Star"
  icon = "fab fa-github" # defaults: "fab fa-github"
+++
