+++
fragment = "items"
weight = 100
background = "light"

title = "Features"
subtitle= "Syna comes with a lot of features"
+++
