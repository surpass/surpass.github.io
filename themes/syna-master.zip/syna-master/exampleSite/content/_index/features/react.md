+++
title = "Built-in React Support"
weight = 30

[asset]
  icon = "fab fa-react"
+++

With React support you can have any component around the web in your website
