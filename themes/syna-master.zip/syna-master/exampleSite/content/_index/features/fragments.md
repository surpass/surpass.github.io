+++
title = "Fragments"
weight = 10

[asset]
  icon = "fas fa-cube"
+++

Syna pages are created using reusable and configurable fragments
