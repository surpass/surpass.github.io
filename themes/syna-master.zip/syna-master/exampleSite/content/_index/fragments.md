+++
fragment = "header"
weight = "200"

background = "light"
title = "Fragments"
subtitle = "Syna comes with a lot of fragments, allowing you to design your pages as you want them"
+++
