+++
title = "Extensible"
weight = 20

[asset]
  icon = "fas fa-boxes"
+++

With Hugo's resource fallthrough you can create and update fragments and Syna will use the new or updated version of those fragments
