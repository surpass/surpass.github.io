+++
title = "Customizable"
weight = 10

[asset]
  icon = "fas fa-pencil-alt"
+++

We use Bootstrap which allows for cutomizing every aspect of the style using variables
