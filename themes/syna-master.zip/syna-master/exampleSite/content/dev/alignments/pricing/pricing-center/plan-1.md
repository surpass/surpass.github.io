+++
weight = 10

title = "Starting plan"
subtitle = "starting at"

price = "Free"
# highlight = true

button_text = "Start for free"
button_url = "#"

[[features]]
  text = "**Basic** feature"
  icon = "fas fa-check"

[[features]]
  text = "**Email** support"
  icon = "fas fa-check"
+++
