+++
fragment = "pricing"
weight = 121
background = "secondary"

title = "Pricing fragment"
subtitle = "Can be linked to 3rd party payment services"
title_align = "center" # Default is center, can be left, right or center
+++

Pricing fragment supports **markdown** as it's subtitle.  
Supports feature listing of different plans and links to a payment service.
