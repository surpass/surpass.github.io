+++
weight = 20

title = "Premium plan"
subtitle = "starting at"

price = "$9.99/mo"
currency = "usd"
highlight = true

button_text = "Get started"
button_url = "/dev/events/payment?topic=pricing:change&plan=Premium plan&price=999&price_text=$9.99/mo&currency=usd"

[[features]]
  text = "**Basic** feature"
  icon = "fas fa-check"

[[features]]
  text = "**Premium** feature"
  icon = "fas fa-check"

[[features]]
  text = "**Email** support"
  icon = "fas fa-check"

[[features]]
  text = "**Chat** support"
  icon = "fas fa-check"
+++
