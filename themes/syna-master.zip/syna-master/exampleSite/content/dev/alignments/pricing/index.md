+++
title = "pricing"
fragment = "content"
weight = 100
+++

Different alignments for pricing fragment
