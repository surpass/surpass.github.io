+++
fragment = "list"
weight = 110
section = "dev/alignments"
count = 1000
summary = false
tiled = true
subsections = false
+++
