+++
title_align="left"

fragment = "graph"
weight = 120
background = "secondary"

title = "Graph Fragment"
subtitle = "Beautifully showcase your data with graphs based on chart.js"
#height = "400px"
#width = "100%"
+++
