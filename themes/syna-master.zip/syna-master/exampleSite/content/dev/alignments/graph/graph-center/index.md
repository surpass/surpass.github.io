+++
title_align="center"

fragment = "graph"
weight = 121
background = "secondary"

title = "Graph Fragment"
subtitle = "Beautifully showcase your data with graphs based on chart.js"
#height = "400px"
#width = "100%"
+++
