+++
fragment = "member"
#disabled = false
date = "2017-10-17"
weight = 142
background = "secondary"

title = "Single Member Fragment"
#subtitle = "Highly motivated Gophers"
title_align = "right" # Default is center, can be left, right or center
+++
