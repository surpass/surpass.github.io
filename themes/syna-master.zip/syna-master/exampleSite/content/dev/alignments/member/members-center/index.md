+++
fragment = "member"
#disabled = false
date = "2017-10-17"
weight = 121
background = "secondary"

title = "Members fragment - Multiple members"
title_align = "center" # Default is center, can be left, right or center
+++
