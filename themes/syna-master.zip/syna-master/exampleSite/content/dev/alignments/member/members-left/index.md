+++
fragment = "member"
#disabled = false
date = "2017-10-17"
weight = 120
background = "secondary"

title = "Members fragment - Multiple members"
title_align = "left" # Default is center, can be left, right or center
+++
