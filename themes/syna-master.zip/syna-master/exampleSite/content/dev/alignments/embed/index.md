+++
title = "embed"
fragment = "content"
weight = 100
+++

Different alignments for embed fragment
