+++
title = "list"
fragment = "content"
weight = 100
+++

Different alignments for list fragment
