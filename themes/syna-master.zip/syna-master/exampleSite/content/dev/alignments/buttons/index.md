+++
title = "buttons"
fragment = "content"
weight = 100
+++

Different alignments for buttons fragment
