+++
title_align="left"

fragment = "item"
#disabled = false
date = "2017-10-04"
weight = 180
background = "secondary"
align = "center"

title = "Item Fragment Icon Center"
#subtitle = ""

# Subtitle pre and post item
#pre = ""
#post = ""

[asset]
  icon = "fas fa-random"
+++

Easily center item fragments even with an icon.

Some more text to showcase the description capabilities:
Lorem ipsum dolor sit amet, consectetur adipiscing elit.
Curabitur a lorem urna.
Quisque in neque malesuada, sollicitudin nunc porttitor, ornare est.
Praesent ante enim, bibendum sed hendrerit et, iaculis laoreet felis.
Morbi efficitur dui sit amet orci porttitor, nec tincidunt turpis elementum.
Suspendisse rutrum, mi ac sollicitudin blandit, eros sem tincidunt enim, vitae feugiat turpis eros ut diam.
Nunc hendrerit, nibh vitae dignissim pretium, magna nulla lacinia massa, et interdum lacus purus ultricies lacus.
Nulla tincidunt quis lacus in posuere.
