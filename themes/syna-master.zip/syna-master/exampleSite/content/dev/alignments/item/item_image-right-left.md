+++
title_align="left"

fragment = "item"
#disabled = false
date = "2017-10-04"
weight = 300
background = "secondary"
align = "right"

title = "Item Fragment Image Right"
subtitle= "Easily right align the item fragment even with an image"

# Subtitle pre and post item
pre = "Awesome screenshot"
post = "Showcasing Syna"

[asset]
  image = "screenshot.png"
+++

Easily left align the item fragment even with an image and buttons at the same time.

Some more text to showcase the description capabilities:
Lorem ipsum dolor sit amet, consectetur adipiscing elit.
Curabitur a lorem urna.
Quisque in neque malesuada, sollicitudin nunc porttitor, ornare est.
Praesent ante enim, bibendum sed hendrerit et, iaculis laoreet felis.
Morbi efficitur dui sit amet orci porttitor, nec tincidunt turpis elementum.
Suspendisse rutrum, mi ac sollicitudin blandit, eros sem tincidunt enim, vitae feugiat turpis eros ut diam.
Nunc hendrerit, nibh vitae dignissim pretium, magna nulla lacinia massa, et interdum lacus purus ultricies lacus.
Nulla tincidunt quis lacus in posuere.
