+++
title = "item"
fragment = "content"
weight = 100
+++

Different alignments for item fragment
