+++
title_align="right"

fragment = "item"
#disabled = false
date = "2017-10-04"
weight = 282
background = "secondary"
align = "center"

title = "Item Fragment Image Only"
#subtitle = ""

# Subtitle pre and post item
#pre = ""
#post = ""

[asset]
  image = "screenshot.png"
+++
