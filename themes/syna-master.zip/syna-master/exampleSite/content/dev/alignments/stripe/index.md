+++
title = "stripe"
fragment = "content"
weight = 100
+++

Different alignments for stripe fragment
