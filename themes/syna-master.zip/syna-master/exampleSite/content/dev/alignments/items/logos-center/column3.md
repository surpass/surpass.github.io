+++
title = "Column 3"
weight = 30

[asset]
  image = "hugo.svg"
  #url = "#"
+++

Showcasing descriptions for column based items
