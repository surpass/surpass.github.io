+++
fragment = "items"
#disabled = false
date = "2017-10-04"
weight = 181
background = "secondary"

title = "Items Fragment with images"
subtitle= "Column based items with images"
title_align = "center" # Default is center, can be left, right or center
+++
