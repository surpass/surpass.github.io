+++
fragment = "items"
#disabled = false
date = "2017-10-04"
weight = 121
background = "secondary"

title = "Items Fragment"
subtitle= "Column based items with icons"
title_align = "center" # Default is center, can be left, right or center
+++
