+++
title = "items"
fragment = "content"
weight = 100
+++

Different alignments for items fragment
