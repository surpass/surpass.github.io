+++
fragment = "items"
#disabled = false
date = "2017-10-04"
weight = 122
background = "secondary"

title = "Items Fragment"
subtitle= "Column based items with icons"
title_align = "right" # Default is center, can be left, right or center
+++
