+++
title = "Column 1"
weight = 10

[asset]
  icon = "fas fa-random"
  url = "#"
+++

Showcasing descriptions for column based items
