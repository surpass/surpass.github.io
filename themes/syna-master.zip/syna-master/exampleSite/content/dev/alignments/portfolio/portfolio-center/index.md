+++
date = "2018-07-09"
fragment = "portfolio"
weight = 121
background = "secondary"

title = "Portfolio Fragment"
subtitle = "Displaying animals with links and modals"
title_align = "center" # Default is center, can be left, right or center

#height = "110px" # Default is auto
+++
