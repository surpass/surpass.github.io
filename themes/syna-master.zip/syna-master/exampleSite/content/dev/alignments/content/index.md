+++
title = "content"
fragment = "content"
weight = 100
+++

Different alignments for content fragment
