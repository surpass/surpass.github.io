+++
fragment = "search"
weight = 122
background = "secondary"

title = "Search Fragment"
subtitle = "Searches through all content fragments"
title_align = "right" # Default is center, can be left, right or center
+++
