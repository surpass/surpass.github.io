+++
fragment = "search"
weight = 121
background = "secondary"

title = "Search Fragment"
subtitle = "Searches through all content fragments"
title_align = "center" # Default is center, can be left, right or center
+++
