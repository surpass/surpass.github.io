+++
title = "search"
fragment = "content"
weight = 100
+++

Different alignments for search fragment
