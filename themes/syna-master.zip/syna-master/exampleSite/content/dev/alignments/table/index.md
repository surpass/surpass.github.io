+++
title = "table"
fragment = "content"
weight = 100
+++

Different alignments for table fragment
