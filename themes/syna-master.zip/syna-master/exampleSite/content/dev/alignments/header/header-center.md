+++
date = "2018-07-13"
fragment = "header"
weight = 121

background = "secondary"
title = "Section Header Fragment"
subtitle = "Even linking is possible. This fragment can be used for related sections so linking is easier."
title_align = "center" # Default is center, can be left, right or center
+++
