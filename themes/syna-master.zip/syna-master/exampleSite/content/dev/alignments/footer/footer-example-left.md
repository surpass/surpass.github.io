+++
title_align="left"

fragment = "footer"
#disabled = true
date = "2016-09-07"
weight = 120
background = "secondary"
title = "Logo Title"

menu_title = "Link Title"

[asset]
  image = "logo.svg"
  text = "Logo Subtext"
  url = "#"
+++

#### Description Title

Project description such as:
Open source theme for your next project
Provided by Okkur Labs
