+++
title = "buttons"
fragment = "content"
weight = 100
+++

Different colors for buttons fragment
