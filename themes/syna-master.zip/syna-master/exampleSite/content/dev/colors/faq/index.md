+++
title = "faq"
fragment = "content"
weight = 100
+++

Different colors for faq fragment
