+++
title = "How to sit on the laptop?"
weight = 10
+++

Cat ipsum dolor sit amet, nap all day yet proudly present butt to human but please stop looking at your phone and pet me, yet furrier and even more furrier hairball. Dismember a mouse and then regurgitate parts of it on the family room floor reward the chosen human with a slow blink find a way to fit in tiny box. Bring your owner a dead bird. Love and coo around boyfriend who purrs and makes the perfect moonlight eyes so i can purr and swat the glittery gleaming yarn to him (the yarn is from a $125 sweater) fight an alligator and win paw at your fat belly.
