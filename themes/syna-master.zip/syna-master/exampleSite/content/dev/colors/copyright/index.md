+++
title = "copyright"
fragment = "content"
weight = 100
+++

Different colors for copyright fragment
