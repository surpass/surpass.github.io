+++
fragment = "graph"
weight = 144
background = "primary"

title = "Graph Fragment"
subtitle = "Beautifully showcase your data with graphs based on chart.js"
#height = "400px"
#width = "100%"
+++
